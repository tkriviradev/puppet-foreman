Facter.add(:check_adobe_installation) do
  has_weight 100
  setcode do
    if File.exists?('C:\ProgramData\Adobe')
       'Adobe is installed'
    else
       'Adobe is not installed'
    end
  end
end
